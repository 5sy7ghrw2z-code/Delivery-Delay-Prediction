# Capstone Graduation Project — Model 2: Delivery Delay Prediction

**Program:** TechTrek — Machine Learning Capstone on E-Commerce
**Model chosen:** Model 2 — Delivery Delay Prediction (Binary Classification)
**Dataset used:** Brazilian E-Commerce Public Dataset by Olist (Kaggle)

## Folder structure

```
capstone_project/
├── data/
│   ├── raw/                       # original Olist CSV files
│   └── Capstone_Clean_Orders.csv  # cleaned, feature-engineered, order-level dataset
├── notebook/
│   └── Capstone_Model2_Analysis.ipynb   # full 17-section notebook (Restart & Run All passes)
├── model/
│   ├── best_model.pkl              # tuned best model (joblib)
│   ├── scaler.pkl                  # fitted StandardScaler
│   └── label_encoders.pkl          # fitted LabelEncoders per categorical column
├── visuals/                        # all required plots, exported as numbered PNGs
├── reports/
│   └── model_comparison.csv        # comparison of all 4 algorithms, weighted & unweighted
└── README.md
```

## Important note on the dataset

The TechTrek brief describes a schema with columns like `Courier`, `Weather`, `Delivery_Status`.
The dataset actually supplied for this project is the **Olist Brazilian E-Commerce dataset**, which
does not contain those exact columns. A full column-mapping table and the reasoning behind every
substitution (e.g. `seller_state` as a courier/logistics proxy, `season` derived from purchase month)
is documented inside the notebook, Section 3 ("Data Audit").

## Headline result

- **Best model:** Decision Tree Classifier (tuned via GridSearchCV, `class_weight=None`)
- **Test-set metrics:** see the "Final Summary" cell at the end of the notebook, and
  `reports/model_comparison.csv` for the full 8-row comparison (4 algorithms × weighted/unweighted).
- Metrics are led by **F1-macro** and **ROC-AUC**, not accuracy, because only ~7.6% of delivered
  orders in this dataset are late.

## How to reproduce

1. Open `notebook/Capstone_Model2_Analysis.ipynb` in Jupyter.
2. Restart & Run All — it reads directly from `../data/raw/`, so no path changes are needed.
3. Outputs (clean CSV, model files, visuals, comparison CSV) will regenerate in place.
